<?php
session_start();
require_once '../include/db.php';

// Check if staff is logged in
if (!isset($_SESSION['staff_id'])) {
    header("Location: ../login.php");
    exit();
}

$staffId = $_SESSION['staff_id'];
$message = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course_id = $_POST['course_id'];
    $session = $_POST['session'];
    $level = $_POST['level'];
    $semester = $_POST['semester'];
    $student_id = $_POST['student_id'];
    $score = $_POST['score'];

    // Grade logic
    $grade = 'F';
    if ($score >= 70) $grade = 'A';
    elseif ($score >= 60) $grade = 'B';
    elseif ($score >= 50) $grade = 'C';
    elseif ($score >= 45) $grade = 'D';
    elseif ($score >= 40) $grade = 'E';

    // Check for duplicate
    $check = $conn->prepare("SELECT * FROM academic_records WHERE student_id = ? AND course_id = ? AND session = ? AND semester = ?");
    $check->bind_param("iiss", $student_id, $course_id, $session, $semester);
    $check->execute();
    $exists = $check->get_result();

    if ($exists->num_rows > 0) {
        $message = "<div class='alert alert-warning'>Result already uploaded for this student/course/semester.</div>";
    } else {
        $insert = $conn->prepare("INSERT INTO academic_records (student_id, course_id, score, grade, session, semester) VALUES (?, ?, ?, ?, ?, ?)");
        $insert->bind_param("iiisss", $student_id, $course_id, $score, $grade, $session, $semester);
        if ($insert->execute()) {
            $message = "<div class='alert alert-success'>Result uploaded successfully!</div>";
        } else {
            $message = "<div class='alert alert-danger'>Failed to upload result.</div>";
        }
    }
}

// Get assigned courses
$courses = $conn->prepare("SELECT c.id, c.code, c.title FROM courses c JOIN staff_courses sc ON sc.course_id = c.id WHERE sc.staff_id = ?");
$courses->bind_param("i", $staffId);
$courses->execute();
$course_result = $courses->get_result();

// Get all students
$students = $conn->query("SELECT id, surname, othernames, matric_no FROM students ORDER BY matric_no ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Upload Student Result</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    :root { --primary-color: #96231c; }
    .bg-primary { background-color: var(--primary-color) !important; }
    body { background-color: #f8f9fa; }
    .container { max-width: 700px; margin-top: 40px; }
  </style>
</head>
<body>

<div class="container">
  <div class="card p-4 shadow-sm">
    <h4 class="mb-4 text-center">📘 Upload Student Result</h4>

    <?= $message ?>

    <form method="post">
      <div class="mb-3">
        <label class="form-label">Select Course</label>
        <select name="course_id" class="form-select" required>
          <option value="">-- Select Course --</option>
          <?php while ($row = $course_result->fetch_assoc()): ?>
            <option value="<?= $row['id'] ?>">
              <?= $row['code'] . ' - ' . $row['title'] ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>

      <div class="row mb-3">
        <div class="col-md-6">
          <label class="form-label">Session</label>
          <input type="text" name="session" class="form-control" placeholder="e.g. 2023/2024" required>
        </div>
        <div class="col-md-3">
          <label class="form-label">Level</label>
          <select name="level" class="form-select" required>
            <option value="100L">100L</option>
            <option value="200L">200L</option>
            <option value="300L">300L</option>
            <option value="400L">400L</option>
          </select>
        </div>
        <div class="col-md-3">
          <label class="form-label">Semester</label>
          <select name="semester" class="form-select" required>
            <option value="First">First</option>
            <option value="Second">Second</option>
          </select>
        </div>
      </div>

      <div class="mb-3">
        <label class="form-label">Select Student</label>
        <select name="student_id" class="form-select" required>
          <option value="">-- Select Student --</option>
          <?php while ($std = $students->fetch_assoc()): ?>
            <option value="<?= $std['id'] ?>">
              <?= $std['matric_no'] . ' - ' . $std['surname'] . ' ' . $std['othernames'] ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>

      <div class="mb-3">
        <label class="form-label">Score (0 - 100)</label>
        <input type="number" name="score" class="form-control" min="0" max="100" required>
      </div>

      <button type="submit" class="btn btn-primary w-100"><i class="bi bi-upload"></i> Upload Result</button>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
