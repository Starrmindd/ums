<?php
session_start();
require_once '../include/db.php';

if (!isset($_SESSION['student_id'])) {
    header("Location: ../login.php");
    exit();
}

$studentId = $_SESSION['student_id'];
$level = $_GET['level'] ?? '';

// Define full fee for each level
$fees = [
    '100L' => 100200,
    '200L' => 100500,
    '300L' => 102500,
    '400L' => 105000,
];

// Validate level
if (!array_key_exists($level, $fees)) {
    die("Invalid level.");
}

$fullFee = $fees[$level];

// Check how much the student has already paid for this level
$stmt = $conn->prepare("SELECT SUM(amount) AS total_paid FROM payments WHERE student_id = ? AND level = ?");
$stmt->bind_param("is", $studentId, $level);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
$alreadyPaid = $result['total_paid'] ?? 0;

// Determine remaining and how much to pay next (60% first, 40% final)
$sixtyPercent = 0.6 * $fullFee;
$fortyPercent = 0.4 * $fullFee;

if ($alreadyPaid >= $fullFee) {
    // Fully paid already
    header("Location: fees.php?paid=1");
    exit();
} elseif ($alreadyPaid == 0) {
    $amountToPay = $sixtyPercent;
} elseif ($alreadyPaid < $fullFee) {
    $amountToPay = $fullFee - $alreadyPaid;
} else {
    die("Unexpected payment condition.");
}

// Simulate payment reference
$reference = strtoupper("PAY" . uniqid());

// Insert payment
$stmt = $conn->prepare("INSERT INTO payments (student_id, level, amount, reference) VALUES (?, ?, ?, ?)");
$stmt->bind_param("isds", $studentId, $level, $amountToPay, $reference);

if ($stmt->execute()) {
    header("Location: fees.php?success=1");
    exit();
} else {
    echo "Payment simulation failed: " . $conn->error;
}
?>
