<?php
session_start();
require_once '../include/db.php';

// Load DomPDF (make sure you installed it via Composer)
require_once '../vendor/autoload.php';

use Dompdf\Dompdf;


if (!isset($_SESSION['student_id'])) {
    header("Location: ../login.php");
    exit();
}

$studentId = $_SESSION['student_id'];
$paymentId = $_GET['id'] ?? null;

if (!$paymentId) {
    die("Invalid payment reference.");
}

// Fetch student and payment info
$stmt = $conn->prepare("SELECT p.*, s.full_name, s.matric_no FROM payments p JOIN students s ON p.student_id = s.id WHERE p.id = ? AND s.id = ?");
$stmt->bind_param("ii", $paymentId, $studentId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Payment not found.");
}

$row = $result->fetch_assoc();

// HTML content for receipt
$html = '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Payment Receipt</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 30px; color: #333; }
        .title { text-align: center; }
        .header h2 { color: #96231c; }
        .info { margin: 20px 0; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        td { padding: 8px; border-bottom: 1px solid #ccc; }
        .footer { margin-top: 40px; font-size: 0.9em; color: #555; text-align: center; }
    </style>
</head>
<body>
    <div class="title">
        <h2>University Management System</h2>
        <h4>Official Payment Receipt</h4>
    </div>

    <div class="info">
        <table>
            <tr><td><strong>Name:</strong></td><td>' . htmlspecialchars($row["full_name"]) . '</td></tr>
            <tr><td><strong>Matric No:</strong></td><td>' . htmlspecialchars($row["matric_no"]) . '</td></tr>
            <tr><td><strong>Level:</strong></td><td>' . htmlspecialchars($row["level"]) . '</td></tr>
            <tr><td><strong>Amount Paid:</strong></td><td>₦' . number_format($row["amount"], 2) . '</td></tr>
            <tr><td><strong>Reference:</strong></td><td>' . htmlspecialchars($row["reference"]) . '</td></tr>
            <tr><td><strong>Payment Date:</strong></td><td>' . date("j M, Y h:i A", strtotime($row["payment_date"])) . '</td></tr>
        </table>
    </div>

    <div class="footer">
        This receipt is electronically generated and does not require a signature.<br>
        &copy; ' . date("Y") . ' UMS Portal
    </div>
</body>
</html>
';

// If download requested
if (isset($_GET['download']) && $_GET['download'] == 1) {
    $dompdf = new Dompdf();
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();
    $dompdf->stream("receipt_{$row['reference']}.pdf", ["Attachment" => true]);
    exit();
}

// Otherwise, just display it in browser with a download button
echo $html;
echo '<div style="text-align:center; margin-top:30px;">
        <a href="view_receipt.php?id=' . $paymentId . '&download=1" class="btn btn-primary">Download PDF</a>
        <a href="javascript:window.print()" class="btn btn-secondary">Print</a>
      </div>';
?>
