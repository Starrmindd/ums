<?php
require_once("../include/db.php");
session_start();

$error = "";

if (isset($_POST['login'])) {
    $matric_no = trim($_POST['matric_no']);
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM students WHERE matric_no = ?");
    $stmt->bind_param("s", $matric_no);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['student_id'] = $user['id'];
            $_SESSION['student_name'] = $user['surname'] . ' ' . $user['othernames'];
            header("Location: student_dashboard.php");
            exit();
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "Invalid matric number.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>OAUSTECH Student Login</title>
  <link rel="stylesheet" href="../assets/css/bootstrap.css"/>
  <link rel="stylesheet" href="../assets/css/style.css"/>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
</head>
<body>
<section class="login-page" style="min-height:100vh; display:flex; align-items:center;">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="card login-card p-4 shadow">
          <div class="text-center mb-3">
            <img src="../assets/images/logo/logo.png" width="70%" alt="OAUSTECH Logo">
            <h5 class="mt-3">Student Login</h5>
          </div>

          <?php if (!empty($error)): ?>
            <div class="alert alert-danger text-center"><?php echo htmlspecialchars($error); ?></div>
          <?php endif; ?>

          <form method="POST" autocomplete="off">
            <div class="mb-3">
              <label for="matric_no" class="form-label">Matric Number</label>
              <input type="text" class="form-control" id="matric_no" name="matric_no" required>
            </div>
            <div class="mb-3">
              <label for="password" class="form-label">Password</label>
              <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" name="login" class="btn btn-primary w-100">Sign In</button>
          </form>

          <div class="text-center mt-3">
            <a href="student_register.php" class="text-decoration-none">Don't have an account? Register</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
</body>
</html>
