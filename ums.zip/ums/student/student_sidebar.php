<!-- student_sidebar.php -->
  <?php

require_once '../include/db.php';

// Check if student is logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: ../login.php");
    exit();
}

// Fetch student data
$studentId = $_SESSION['student_id'];
$query = $conn->prepare("SELECT * FROM students WHERE id = ?");
$query->bind_param("i", $studentId);
$query->execute();
$result = $query->get_result();
$student = $result->fetch_assoc();

// Sample data placeholders (replace with actual DB queries)
$enrolledCourses = 7; // Replace with real count
$cgpa = 3.85; // Replace with actual calculation
$feesStatus = "Paid"; // Replace with actual finance check
?>

  <style>
    :root {
      --primary-color: #96231c;
    }
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f8f9fa;
    }
    .bg-primary,
    .btn-primary {
      background-color: var(--primary-color) !important;
      border-color: var(--primary-color) !important;
    }
    .sidebar {
      width: 250px;
      min-height: 100vh;
      background-color: var(--primary-color);
      color: white;
      position: fixed;
      transition: width 0.3s ease;
      overflow: hidden;
    }
    .sidebar.collapsed { width: 80px; }
    .sidebar .logo {
      font-size: 1.2rem;
      font-weight: bold;
      padding: 1rem;
      text-align: center;
      white-space: nowrap;
    }
    .sidebar a {
      color: white;
      text-decoration: none;
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 15px;
      transition: background 0.2s;
    }
    .sidebar a:hover { background: rgba(255, 255, 255, 0.1); }
    .sidebar.collapsed a span { display: none; }
    .content {
      margin-left: 250px;
      padding: 20px;
      transition: margin-left 0.3s ease;
    }
    .content.collapsed { margin-left: 80px; }
    .toggle-btn {
      position: fixed;
      left: 260px;
      top: 15px;
      z-index: 1001;
      transition: left 0.3s ease;
    }
    .content.collapsed + .toggle-btn { left: 90px; }
    .card { box-shadow: 0 4px 8px rgba(0,0,0,0.05); }
    .chart-container {
      background: #fff;
      padding: 20px;
      border-radius: 8px;
      margin-top: 30px;
    }
    @media (max-width: 768px) {
      .sidebar {
        position: absolute;
        z-index: 1050;
      }
    }
  </style>
<div id="sidebar" class="sidebar">
  <div class="logo">🎓 <span>Student Panel</span></div>
  <a href="student_dashboard.php"><i class="bi bi-house"></i> <span>Dashboard</span></a>
  <a href="my_courses.php"><i class="bi bi-journal-bookmark-fill"></i> <span>My Courses</span></a>
  <a href="my_results.php"><i class="bi bi-bar-chart-line-fill"></i> <span>My Results</span></a>
  <a href="fees.php"><i class="bi bi-cash-stack"></i> <span>Fees & Payment</span></a>
  <a href="student_profile.php"><i class="bi bi-person-circle"></i> <span>Profile</span></a>
  <a href="materials.php"><i class="bi bi-folder2-open"></i> <span>Materials</span></a>
  <a href="feedback.php"><i class="bi bi-chat-left-dots"></i> <span>Feedback</span></a>
  <a href="settings.php"><i class="bi bi-gear"></i> <span>Settings</span></a>
</div>
<!-- toggle_sidebar.php -->
<button id="toggleSidebar" class="btn btn-outline-secondary toggle-btn">
  <i class="bi bi-list"></i>
</button>
<!-- Main Content -->
  <div id="content" class="content">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4 rounded">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">UMS Dashboard</a>
        <div class="dropdown ms-auto">
          <a class="text-white text-decoration-none dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
            <i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($student['surname']); ?>
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item" href="student_profile.php">Profile</a></li>
            <li><a class="dropdown-item" href="../student/logout.php">Logout</a></li>
          </ul>
        </div>
      </div>
    </nav>

<script>
  const toggleBtn = document.getElementById('toggleSidebar');
  const sidebar = document.getElementById('sidebar');
  const content = document.getElementById('content');

  toggleBtn.addEventListener('click', () => {
    sidebar.classList.toggle('collapsed');
    content.classList.toggle('collapsed');
  });
</script>
