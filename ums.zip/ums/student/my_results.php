<?php
session_start();
require_once '../include/db.php';

if (!isset($_SESSION['student_id'])) {
    header("Location: ../login.php");
    exit();
}

$studentId = $_SESSION['student_id'];
$selectedLevel = $_GET['level'] ?? '';
$selectedSemester = $_GET['semester'] ?? '';

$records = [];
$gpaSummary = [];

if (!empty($selectedLevel) || !empty($selectedSemester)) {
    $sql = "SELECT c.course_code, c.course_title, c.unit, ar.score, ar.grade, ar.session, ar.semester, c.level
            FROM academic_records ar
            JOIN courses c ON ar.course_id = c.id
            WHERE ar.student_id = ?";

    $params = [$studentId];
    $types = "i";

    if (!empty($selectedLevel)) {
        $sql .= " AND c.level = ?";
        $types .= "s";
        $params[] = $selectedLevel;
    }

    if (!empty($selectedSemester)) {
        $sql .= " AND ar.semester = ?";
        $types .= "s";
        $params[] = $selectedSemester;
    }

    $sql .= " ORDER BY ar.session DESC, ar.semester DESC";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $results = $stmt->get_result();

    $grades = ['A' => 5, 'B' => 4, 'C' => 3, 'D' => 2, 'E' => 1, 'F' => 0];

    while ($row = $results->fetch_assoc()) {
        $session = $row['session'];
        $semester = $row['semester'];
        $unit = (int)$row['unit'];
        $gradePoint = $grades[$row['grade']] ?? 0;
        $points = $unit * $gradePoint;

        $records[] = $row;

        if (!isset($gpaSummary[$session])) {
            $gpaSummary[$session] = ['semesters' => [], 'total_units' => 0, 'total_points' => 0];
        }
        if (!isset($gpaSummary[$session]['semesters'][$semester])) {
            $gpaSummary[$session]['semesters'][$semester] = ['units' => 0, 'points' => 0];
        }

        $gpaSummary[$session]['semesters'][$semester]['units'] += $unit;
        $gpaSummary[$session]['semesters'][$semester]['points'] += $points;
        $gpaSummary[$session]['total_units'] += $unit;
        $gpaSummary[$session]['total_points'] += $points;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Results | UMS</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    :root { --primary-color: #96231c; }
    body { background-color: #f8f9fa; }
    .bg-primary { background-color: var(--primary-color) !important; }
    .table thead { background-color: var(--primary-color); color: white; }
  </style>
</head>
<body>
<?php include 'student_sidebar.php'; ?>
<div class="content" style="margin-left:250px; padding:2rem;">
  <h2 class="mb-4">📊 My Results</h2>

  <!-- Filter Form -->
  <form method="get" class="row g-3 mb-4">
    <div class="col-md-4">
      <label class="form-label">Level</label>
      <select name="level" class="form-select">
        <option value="">-- All Levels --</option>
        <?php foreach (['100L', '200L', '300L', '400L'] as $level): ?>
          <option value="<?= $level ?>" <?= $selectedLevel == $level ? 'selected' : '' ?>><?= $level ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4">
      <label class="form-label">Semester</label>
      <select name="semester" class="form-select">
        <option value="">-- All Semesters --</option>
        <?php foreach (['First', 'Second'] as $sem): ?>
          <option value="<?= $sem ?>" <?= $selectedSemester == $sem ? 'selected' : '' ?>><?= $sem ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4 d-flex align-items-end">
      <button type="submit" class="btn btn-primary w-100"><i class="bi bi-funnel-fill"></i> Filter</button>
    </div>
  </form>

  <?php if (!empty($records)): ?>
    <!-- Results Table -->
    <div class="table-responsive mb-4">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Course Code</th>
            <th>Title</th>
            <th>Unit</th>
            <th>Score</th>
            <th>Grade</th>
            <th>Session</th>
            <th>Semester</th>
            <th>Level</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($records as $row): ?>
            <tr>
              <td><?= htmlspecialchars($row['course_code']) ?></td>
              <td><?= htmlspecialchars($row['course_title']) ?></td>
              <td><?= htmlspecialchars($row['unit']) ?></td>
              <td><?= htmlspecialchars($row['score']) ?></td>
              <td><?= htmlspecialchars($row['grade']) ?></td>
              <td><?= htmlspecialchars($row['session']) ?></td>
              <td><?= htmlspecialchars($row['semester']) ?></td>
              <td><?= htmlspecialchars($row['level']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- GPA & CGPA Summary -->
    <h5 class="mb-3">🎓 GPA & CGPA Summary</h5>
    <?php foreach ($gpaSummary as $session => $data): ?>
      <div class="card mb-3">
        <div class="card-header bg-primary text-white">
          Session: <?= htmlspecialchars($session) ?>
        </div>
        <div class="card-body">
          <?php foreach ($data['semesters'] as $semester => $sData): ?>
            <p><strong><?= $semester ?> Semester GPA:</strong> 
              <?= $sData['units'] > 0 ? round($sData['points'] / $sData['units'], 2) : '0.00' ?>
              (<?= $sData['points'] ?> pts / <?= $sData['units'] ?> units)
            </p>
          <?php endforeach; ?>
          <p><strong>CGPA for <?= $session ?>:</strong> 
            <?= $data['total_units'] > 0 ? round($data['total_points'] / $data['total_units'], 2) : '0.00' ?>
            (<?= $data['total_points'] ?> pts / <?= $data['total_units'] ?> units)
          </p>
        </div>
      </div>
    <?php endforeach; ?>

  <?php elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && (!empty($selectedLevel) || !empty($selectedSemester))): ?>
    <div class="alert alert-warning">No results found for the selected filters.</div>
  <?php else: ?>
    <div class="alert alert-info">Please select level or semester to view results.</div>
  <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
