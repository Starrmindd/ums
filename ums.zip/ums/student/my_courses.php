<?php

session_start();
require_once '../include/db.php';

if (!isset($_SESSION['student_id'])) {
    header("Location: ../login.php");
    exit();
}

$studentId = $_SESSION['student_id'];

$filter_semester = $_GET['semester'] ?? '';
$filter_level = $_GET['level'] ?? '';

// Prepare filtering condition
$filter_sql = "AND c.semester LIKE ? AND c.level LIKE ?";
$semester_param = $filter_semester ? $filter_semester : '%';
$level_param = $filter_level ? $filter_level : '%';

// Fetch registered courses
$stmt = $conn->prepare("
    SELECT c.course_code, c.course_title, c.unit, c.semester, c.level
    FROM course_registrations cr
    JOIN courses c ON cr.course_id = c.id
    WHERE cr.student_id = ? $filter_sql
");
$stmt->bind_param("iss", $studentId, $semester_param, $level_param);
$stmt->execute();
$registered = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Total Units
$total_units = array_sum(array_column($registered, 'unit'));

// Fetch available (unregistered) courses
$available = $conn->prepare("
    SELECT c.id, c.course_code, c.course_title, c.unit, c.semester, c.level
    FROM courses c
    WHERE CONCAT(c.semester, '-', c.level) LIKE CONCAT(?, '-', ?)
    AND c.id NOT IN (
        SELECT course_id FROM course_registrations WHERE student_id = ?
    )
");
$available->bind_param("ssi", $semester_param, $level_param, $studentId);
$available->execute();
$available_courses = $available->get_result()->fetch_all(MYSQLI_ASSOC);

// Register new course
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['course_ids'])) {
    $course_ids = $_POST['course_ids'];
    foreach ($course_ids as $course_id) {
        $reg = $conn->prepare("INSERT INTO course_registrations (student_id, course_id) VALUES (?, ?)");
        $reg->bind_param("ii", $studentId, $course_id);
        $reg->execute();
    }
    header("Location: my_courses.php?semester=$filter_semester&level=$filter_level&success=1");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Courses | UMS</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    :root { --primary-color: #96231c; }
    .bg-primary { background-color: var(--primary-color) !important; }
    .table th { background-color: var(--primary-color); color: white; }
  </style>
</head>
<body>
<?php include 'student_sidebar.php'; ?>



<div class="container mt-4">
  <h4 class="mb-3">My Enrolled Courses</h4>

  <form method="get" class="row g-3 mb-4">
    <div class="col-md-4">
      <select name="semester" class="form-select" onchange="this.form.submit()">
        <option value="">-- Filter by Semester --</option>
        <option value="First" <?= $filter_semester === "First" ? 'selected' : '' ?>>First</option>
        <option value="Second" <?= $filter_semester === "Second" ? 'selected' : '' ?>>Second</option>
      </select>
    </div>
    <div class="col-md-4">
      <select name="level" class="form-select" onchange="this.form.submit()">
        <option value="">-- Filter by Level --</option>
        <option value="100" <?= $filter_level === "100" ? 'selected' : '' ?>>100</option>
        <option value="200" <?= $filter_level === "200" ? 'selected' : '' ?>>200</option>
        <option value="300" <?= $filter_level === "300" ? 'selected' : '' ?>>300</option>
        <option value="400" <?= $filter_level === "400" ? 'selected' : '' ?>>400</option>
      </select>
    </div>
  </form>

  <?php if (isset($_GET['success'])): ?>
    <div class="alert alert-success">New courses registered successfully.</div>
  <?php endif; ?>

  <div class="card p-3 shadow-sm mb-5">
    <?php if (count($registered)): ?>
      <div class="table-responsive">
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>Course Code</th>
              <th>Course Title</th>
              <th>Unit</th>
              <th>Semester</th>
              <th>Level</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($registered as $c): ?>
              <tr>
                <td><?= $c['course_code'] ?></td>
                <td><?= $c['course_title'] ?></td>
                <td><?= $c['unit'] ?></td>
                <td><?= $c['semester'] ?></td>
                <td><?= $c['level'] ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <div class="text-end fw-bold">Total Units: <?= $total_units ?></div>
    <?php else: ?>
      <div class="alert alert-warning">No courses registered.</div>
    <?php endif; ?>
  </div>

  <?php if (count($available_courses)): ?>
    <h5 class="mb-3">Available Courses (<?= $filter_semester ?: 'All Semesters' ?> - <?= $filter_level ?: 'All Levels' ?>)</h5>
    <form method="post" class="card p-3 shadow-sm mb-5">
      <div class="table-responsive">
        <table class="table table-bordered">
          <thead class="table-light">
            <tr>
              <th></th>
              <th>Code</th>
              <th>Title</th>
              <th>Unit</th>
              <th>Semester</th>
              <th>Level</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($available_courses as $c): ?>
              <tr>
                <td><input type="checkbox" name="course_ids[]" value="<?= $c['id'] ?>"></td>
                <td><?= $c['course_code'] ?></td>
                <td><?= $c['course_title'] ?></td>
                <td><?= $c['unit'] ?></td>
                <td><?= $c['semester'] ?></td>
                <td><?= $c['level'] ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <button class="btn btn-success w-100" type="submit">Register Selected Courses</button>
    </form>
  <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
