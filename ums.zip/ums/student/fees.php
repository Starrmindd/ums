<?php
session_start();
require_once '../include/db.php';

if (!isset($_SESSION['student_id'])) {
    header("Location: ../login.php");
    exit();
}

$studentId = $_SESSION['student_id'];

// Define fees by level
$feeByLevel = [
    '100L' => 100200,
    '200L' => 100500,
    '300L' => 102500,
    '400L' => 105000,
];

// Fetch all payments for the student
$stmt = $conn->prepare("SELECT * FROM payments WHERE student_id = ? ORDER BY payment_date DESC");
$stmt->bind_param("i", $studentId);
$stmt->execute();
$paymentsResult = $stmt->get_result();

$payments = [];
$paidByLevel = [];

while ($row = $paymentsResult->fetch_assoc()) {
    $payments[] = $row;
    $lvl = $row['level'];
    if (!isset($paidByLevel[$lvl])) $paidByLevel[$lvl] = 0;
    $paidByLevel[$lvl] += $row['amount'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Fees & Payments | UMS</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    :root { --primary-color: #96231c; }
    body { background-color: #f8f9fa; }
    .bg-primary { background-color: var(--primary-color) !important; }
    .table thead { background-color: var(--primary-color); color: white; }
  </style>
</head>
<body>

<?php include 'student_sidebar.php'; ?>

<div class="content" style="margin-left:250px; padding:2rem;">
  <h2 class="mb-4">💳 My Fees & Payments</h2>

  <!-- Level Fee Status -->
  <?php foreach ($feeByLevel as $level => $feeAmount): 
    $paid = $paidByLevel[$level] ?? 0;
    $status = $paid >= $feeAmount ? 'Paid' : ($paid > 0 ? 'Partially Paid' : 'Not Paid');
    $badgeClass = $status === 'Paid' ? 'success' : ($status === 'Partially Paid' ? 'warning text-dark' : 'danger');
  ?>
    <div class="card mb-3">
      <div class="card-body">
        <h5><?= $level ?> Level</h5>
        <p><strong>Total Fee:</strong> ₦<?= number_format($feeAmount) ?></p>
        <p><strong>Paid:</strong> ₦<?= number_format($paid) ?></p>
        <p><strong>Status:</strong> <span class="badge bg-<?= $badgeClass ?>"><?= $status ?></span></p>

        <?php if ($paid < $feeAmount): ?>
          <a href="simulate_payment.php?level=<?= $level ?>" class="btn btn-outline-success">
            <i class="bi bi-cash-stack"></i> Pay Now for <?= $level ?>
          </a>
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; ?>

  <!-- Payment History Table -->
  <h5 class="mt-5">📜 Payment History</h5>
  <div class="table-responsive">
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>Payment ID</th>
          <th>Level</th>
          <th>Amount</th>
          <th>Date</th>
          <th>Reference</th>
          <th>Receipt</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($payments)): ?>
          <?php foreach ($payments as $row): ?>
            <tr>
              <td><?= $row['id'] ?></td>
              <td><?= $row['level'] ?></td>
              <td>₦<?= number_format($row['amount']) ?></td>
              <td><?= date("j M, Y", strtotime($row['payment_date'])) ?></td>
              <td><?= $row['reference'] ?></td>
              <td><a href="view_receipt.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-primary"><i class="bi bi-receipt"></i> View</a></td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="6" class="text-center text-muted">No payments made yet.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
