<?php
session_start();
require_once '../include/db.php';

if (!isset($_SESSION['student_id'])) {
    header("Location: ../login.php");
    exit();
}

$paymentId = $_GET['id'] ?? 0;
$studentId = $_SESSION['student_id'];

$stmt = $conn->prepare("SELECT p.*, s.surname, s.othernames, s.matric_no 
                        FROM payments p 
                        JOIN students s ON p.student_id = s.id 
                        WHERE p.id = ? AND p.student_id = ?");
$stmt->bind_param("ii", $paymentId, $studentId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Receipt not found.");
}

$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Payment Receipt</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #fff;
      padding: 2rem;
      font-family: 'Segoe UI', sans-serif;
    }
    .receipt-box {
      max-width: 750px;
      margin: auto;
      border: 1px solid #ccc;
      padding: 2rem;
      box-shadow: 0 0 10px rgba(0,0,0,0.05);
    }
    .header {
      text-align: center;
      margin-bottom: 2rem;
    }
    .header img {
      width: 80px;
    }
    .title {
      font-size: 22px;
      margin-top: 1rem;
      color: #96231c;
    }
    .table th {
      width: 25%;
    }
    .text-end {
      text-align: right;
    }
    @media print {
      .print-btn {
        display: none;
      }
    }
  </style>
</head>
<body>

<div class="receipt-box">
  <div class="header">
    <img src="../assets/images/logo/logo.png" alt="OAUSTECH Logo">
    <h4 class="title">OAUSTECH - Payment Receipt</h4>
  </div>

  <table class="table table-bordered">
    <tbody>
      <tr>
        <th>Payment ID:</th>
        <td><?= $row['id'] ?></td>
        <th>Payment Date:</th>
        <td><?= date("j M Y, H:i a", strtotime($row['payment_date'])) ?></td>
      </tr>
      <tr>
        <th>Matric Number:</th>
        <td><?= htmlspecialchars($row['matric_no']) ?></td>
        <th>Full Name:</th>
        <td><?= htmlspecialchars($row['surname'] . ' ' . $row['othernames']) ?></td>
      </tr>
      <tr>
        <th>Level:</th>
        <td><?= htmlspecialchars($row['level']) ?></td>
        <th>Amount Paid:</th>
        <td><strong>₦<?= number_format($row['amount'], 2) ?></strong></td>
      </tr>
      <tr>
        <th>Reference:</th>
        <td colspan="3"><?= htmlspecialchars($row['reference']) ?></td>
      </tr>
    </tbody>
  </table>

  <div class="mt-4">
    <p class="text-muted text-center">This receipt is system-generated and valid without a physical signature.</p>
  </div>

  <div class="text-center print-btn mt-3">
    <button class="btn btn-primary" onclick="window.print()">
      <i class="bi bi-printer"></i> Print Receipt
    </button>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
