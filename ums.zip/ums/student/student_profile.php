<?php
session_start();
require_once '../include/db.php';

// Check if student is logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: ../login.php");
    exit();
}

// Fetch student data
$studentId = $_SESSION['student_id'];
$query = $conn->prepare("SELECT * FROM students WHERE id = ?");
$query->bind_param("i", $studentId);
$query->execute();
$result = $query->get_result();
$student = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Profile | UMS</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap & Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    :root {
      --primary-color: #96231c;
    }
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f8f9fa;
    }
    .bg-primary {
      background-color: var(--primary-color) !important;
    }
    .card {
      box-shadow: 0 4px 8px rgba(0,0,0,0.05);
    }
    .profile-label {
      font-weight: 600;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">UMS | Student Profile</a>
    <div class="dropdown ms-auto">
      <a class="text-white text-decoration-none dropdown-toggle" href="#" data-bs-toggle="dropdown">
        <i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($student['surname']); ?>
      </a>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="student_dashboard.php">Dashboard</a></li>
        <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="card p-4">
        <h4 class="mb-4">My Profile</h4>
        <div class="row mb-3">
          <div class="col-md-6">
            <span class="profile-label">Surname:</span>
            <div><?php echo htmlspecialchars($student['surname']); ?></div>
          </div>
          <div class="col-md-6">
            <span class="profile-label">Other Names:</span>
            <div><?php echo htmlspecialchars($student['othernames']); ?></div>
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-6">
            <span class="profile-label">Matric Number:</span>
            <div><?php echo htmlspecialchars($student['matric_no']); ?></div>
          </div>
          <div class="col-md-6">
            <span class="profile-label">Email:</span>
            <div><?php echo htmlspecialchars($student['email'] ?? 'N/A'); ?></div>
          </div>
        </div>

        <!-- Add more fields if available -->
        <div class="row mb-3">
          <div class="col-md-6">
            <span class="profile-label">Department:</span>
            <div><?php echo htmlspecialchars($student['department'] ?? 'N/A'); ?></div>
          </div>
          <div class="col-md-6">
            <span class="profile-label">Level:</span>
            <div><?php echo htmlspecialchars($student['level'] ?? 'N/A'); ?></div>
          </div>
        </div>

        <div class="text-end mt-3">
          <a href="edit_profile.php" class="btn btn-outline-primary">Edit Profile</a>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
