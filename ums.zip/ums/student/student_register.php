<?php
require_once("../include/db.php");

if (isset($_POST['register'])) {
    $surname = trim($_POST['surname']);
    $othernames = trim($_POST['othernames']);
    $matric_no = trim($_POST['matric_no']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Check if matric number already exists
    $check = $conn->prepare("SELECT * FROM students WHERE matric_no = ?");
    $check->bind_param("s", $matric_no);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        $error = "Matric number already exists!";
    } else {
        // Insert new student
        $stmt = $conn->prepare("INSERT INTO students (surname, othernames, matric_no, password) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $surname, $othernames, $matric_no, $password);

        if ($stmt->execute()) {
            $success = "Registration successful! You can now log in.";
        } else {
            $error = "Something went wrong. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Student Registration</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card p-4">
        <h2 class="mb-4">Student Registration</h2>

        <?php if (isset($error)): ?>
          <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php elseif (isset($success)): ?>
          <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <form method="post" action="">
          <div class="mb-3">
            <label>Surname</label>
            <input type="text" name="surname" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Other Names</label>
            <input type="text" name="othernames" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Matric Number</label>
            <input type="text" name="matric_no" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required>
          </div>
          <button name="register" class="btn btn-primary w-100">Register</button>
         <div class="text-center mt-3">
            <a href="student_login.php" class="text-decoration-none">Already have an account? Login</a>
          </div>
      
        </form>
      </div>
    </div>
  </div>
</div>
</body>
</html>
