<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>UMS Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container mt-5">
    <div class="row justify-content-center">
      <div class="col-md-5">
        <div class="card">
          <div class="card-header bg-dark text-white">
            <h4 class="text-center">UMS Login</h4>
          </div>
          <div class="card-body">
            <?php if (isset($_SESSION['error'])): ?>
              <div class="alert alert-danger"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>
           <form method="POST" action="process_login.php">
    <input type="text" name="surname" placeholder="Surname" required><br>
    <input type="text" name="id_number" placeholder="Matric No or Staff ID" required><br>
    <select name="role" required>
        <option value="student">Student</option>
        <option value="staff">Staff</option>
    </select><br>
    <button type="submit">Login</button>
</form>

          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
