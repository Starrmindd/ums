<?php
session_start();
require_once '../config/db.php';

function login($email, $password, $role) {
    global $pdo;
    $table = ($role === 'student') ? 'students' : 'staff';

    $stmt = $pdo->prepare("SELECT * FROM $table WHERE email = :email LIMIT 1");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = $role;
        $_SESSION['user_name'] = $user['fullname'];
        
        // Redirect based on role
        if ($role === 'student') {
            header("Location: ../students/dashboard.php");
        } else {
            header("Location: ../staff/dashboard.php");
        }
        exit();
    } else {
        $_SESSION['error'] = "Invalid login credentials.";
        header("Location: ../login.php");
        exit();
    }
}
?>
