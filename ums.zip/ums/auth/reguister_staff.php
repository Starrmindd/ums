<?php
require_once 'config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $surname = $_POST['surname'];
    $othernames = $_POST['othernames'];
    $staff_id = $_POST['staff_id'];
    $role = $_POST['role'];

    $stmt = $pdo->prepare("INSERT INTO staff (surname, othernames, staff_id, role) VALUES (?, ?, ?, ?)");
    if ($stmt->execute([$surname, $othernames, $staff_id, $role])) {
        echo "Staff registered successfully!";
    } else {
        echo "Error registering staff.";
    }
}
?>

<form method="POST">
    <input type="text" name="surname" placeholder="Surname" required><br>
    <input type="text" name="othernames" placeholder="Other Names" required><br>
    <input type="text" name="staff_id" placeholder="Staff ID" required><br>
    <input type="text" name="role" placeholder="Role" required><br>
    <button type="submit">Register Staff</button>
</form>
