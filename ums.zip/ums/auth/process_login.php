<?php
session_start();
require_once 'config/db.php';

$surname = $_POST['surname'];
$id_number = $_POST['id_number'];
$role = $_POST['role'];

if ($role == 'student') {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE surname = ? AND matric_no = ?");
} else {
    $stmt = $pdo->prepare("SELECT * FROM staff WHERE surname = ? AND staff_id = ?");
}

$stmt->execute([$surname, $id_number]);
$user = $stmt->fetch();

if ($user) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_role'] = $role;
    $_SESSION['user_name'] = $user['surname'] . ' ' . $user['othernames'];
    
    if ($role === 'student') {
        header("Location: students/dashboard.php");
    } else {
        header("Location: staff/dashboard.php");
    }
} else {
    $_SESSION['error'] = "Invalid login credentials.";
    header("Location: login.php");
}
?>
