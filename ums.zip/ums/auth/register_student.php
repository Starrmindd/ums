<?php
require_once 'config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $surname = $_POST['surname'];
    $othernames = $_POST['othernames'];
    $matric_no = $_POST['matric_no'];
    $department = $_POST['department'];

    $stmt = $pdo->prepare("INSERT INTO students (surname, othernames, matric_no, department) VALUES (?, ?, ?, ?)");
    if ($stmt->execute([$surname, $othernames, $matric_no, $department])) {
        echo "Student registered successfully!";
    } else {
        echo "Error registering student.";
    }
}
?>

<form method="POST">
    <input type="text" name="surname" placeholder="Surname" required><br>
    <input type="text" name="othernames" placeholder="Other Names" required><br>
    <input type="text" name="matric_no" placeholder="Matric Number" required><br>
    <input type="text" name="department" placeholder="Department" required><br>
    <button type="submit">Register Student</button>
</form>
